# CKFinder 3 Basic Standalone Web Application

This sample illustrates [minimalistic setup](http://docs.cksource.com/ckfinder3-net/quickstart.html) needed to run CKFinder.
